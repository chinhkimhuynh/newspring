package com.fpt.finalapp.Utils;

import com.fpt.finalapp.entities.TaiKhoan;

public interface LoginUtil {
	
	public TaiKhoan layTaiKhoanBoiId(String username);

}
