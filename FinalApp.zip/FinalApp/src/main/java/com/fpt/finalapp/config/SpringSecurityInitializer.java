/**
 * 
 */
package com.fpt.finalapp.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * @author HCD-Fresher055
 *
 */
public class SpringSecurityInitializer extends AbstractSecurityWebApplicationInitializer{

}
